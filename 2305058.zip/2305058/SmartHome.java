import java.util.*;

interface SmartDevice {
    void activate();
    void deactivate();
    double getPowerUsage();
    String getStatus();
    SmartDevice getBaseDevice(); 
}

interface DeviceContainer extends SmartDevice {
    List<SmartDevice> getDevices();
    void addDevice(SmartDevice device);
    void removeDevice(SmartDevice device);
    String getName();
}

class SmartLight implements SmartDevice {
    private boolean enlightened = false;

    public void activate() { enlightened = true; }
    public void deactivate() { enlightened = false; }
    public double getPowerUsage() { return enlightened ? 10.0 : 0.0; }
    public String getStatus() { return "light " + (enlightened ? "on" : "off"); }
    public SmartDevice getBaseDevice() { return this; }
}

class SmartThermostat implements SmartDevice {
    private boolean heated = false;

    public void activate() { heated = true; }
    public void deactivate() { heated = false; }
    public double getPowerUsage() { return heated ? 150.0 : 0.0; }
    public String getStatus() { return "thermostat " + (heated ? "on" : "off"); }
    public SmartDevice getBaseDevice() { return this; }
}

class SmartSpeaker implements SmartDevice {
    private boolean playing = false;

    public void activate() { playing = true; }
    public void deactivate() { playing = false; }
    public double getPowerUsage() { return playing ? 5.0 : 0.0; }
    public String getStatus() { return "speaker " + (playing ? "playing" : "idle"); }
    public SmartDevice getBaseDevice() { return this; }
}

class Room implements DeviceContainer {
    private final String name;
    private final List<SmartDevice> devices = new ArrayList<>();

    public Room(String name) { this.name = name; }
    public String getName() { return name; }

    public void activate() {
        for (SmartDevice device : devices) device.activate();
    }
    public void deactivate() {
        for (SmartDevice device : devices) device.deactivate();
    }
    public double getPowerUsage() {
        double total = 0;
        for (SmartDevice device : devices) total += device.getPowerUsage();
        return total;
    }
    public String getStatus() {
        StringBuilder sb = new StringBuilder(name);
        for (SmartDevice device : devices) {
            sb.append("\n").append(device.getStatus());
        }
        return sb.toString();
    }
    public void addDevice(SmartDevice device) { devices.add(device); }
    public void removeDevice(SmartDevice device) { devices.remove(device); }
    public List<SmartDevice> getDevices() { return devices; }
    public SmartDevice getBaseDevice() { return this; }
}

class Home implements DeviceContainer {
    private final String name;
    private final List<SmartDevice> children = new ArrayList<>();

    public Home(String name) { this.name = name; }
    public String getName() { return name; }

    public void activate() {
        for (SmartDevice child : children) child.activate();
    }
    public void deactivate() {
        for (SmartDevice child : children) child.deactivate();
    }
    public double getPowerUsage() {
        double total = 0;
        for (SmartDevice child : children) total += child.getPowerUsage();
        return total;
    }
    public String getStatus() {
        StringBuilder sb = new StringBuilder("Home " + name);
        for (SmartDevice child : children) {
            sb.append("\n").append(child.getStatus());
        }
        return sb.toString();
    }
    public void addDevice(SmartDevice device) { children.add(device); }
    public void removeDevice(SmartDevice device) { children.remove(device); }
    public List<SmartDevice> getDevices() { return children; }
    public SmartDevice getBaseDevice() { return this; }
    public void addRoom(SmartDevice room) { addDevice(room); }
    public List<SmartDevice> getRooms() { return getDevices(); }
}

abstract class DeviceDecorator implements SmartDevice {
    protected final SmartDevice wrappedDevice;

    public DeviceDecorator(SmartDevice device) {
        this.wrappedDevice = device;
    }
    public SmartDevice getDecorated() { return wrappedDevice; }
    public SmartDevice getBaseDevice() { return wrappedDevice.getBaseDevice(); }

    public void activate() { wrappedDevice.activate(); }
    public void deactivate() { wrappedDevice.deactivate(); }
    public double getPowerUsage() { return wrappedDevice.getPowerUsage(); }
    public String getStatus() { return wrappedDevice.getStatus(); }
}

class AccessRestricted extends DeviceDecorator {
    private final int pinnum;
    private boolean locked = true;

    public AccessRestricted(SmartDevice device, int pin) {
        super(device);
        this.pinnum = pin;
    }

    public void unlock(int triedpin) {
        if (this.pinnum == triedpin) this.locked = false;
    }
    public void lock() { this.locked = true; }

    @Override
    public void activate() {
        if (!locked) super.activate();
    }
    @Override
    public void deactivate() {
        if (!locked) super.deactivate();
    }
    @Override
    public String getStatus() {
        String superStatus = super.getStatus();
        return locked ? superStatus + " LOCKED" : superStatus;
    }
}

class TimerControlled extends DeviceDecorator {
    private final int duration;
    private boolean isTimed = true;

    public TimerControlled(SmartDevice device, int time) {
        super(device);
        this.duration = time;
    }

    @Override
    public void activate() {
        super.activate();
        isTimed = true;
    }
    @Override
    public void deactivate() {
        super.deactivate();
        this.isTimed = false;
    }
    @Override
    public String getStatus() {
        String superStatus = super.getStatus();
        return isTimed ? superStatus + " auto-off in " + duration + "s" : superStatus + " (timer is off)";
    }
    public void simulateTimerExpiry() {
        if (isTimed) {
            super.deactivate();
            this.isTimed = false;
        }
    }
}

class PowerThrottled extends DeviceDecorator {
    private final double powerlimit;

    public PowerThrottled(SmartDevice device, double limit) {
        super(device);
        this.powerlimit = limit;
    }

    @Override
    public double getPowerUsage() {
        return Math.min(super.getPowerUsage(), powerlimit);
    }
    @Override
    public String getStatus() {
        String superStatus = super.getStatus();
        if (super.getPowerUsage() > powerlimit && super.getPowerUsage() > 0) {
            return superStatus + " throttled to " + powerlimit + "W";
        }
        return superStatus;
    }
}


class EcoMode extends DeviceDecorator implements DeviceContainer {
    private final double budget;
    private final DeviceContainer container;

    public EcoMode(DeviceContainer container, double budget) {
        super(container);
        this.container = container;
        this.budget = budget;
    }

    @Override
    public void activate() {
        super.activate();
        enforceBudget();
    }

    private void enforceBudget() {
        List<SmartDevice> devices = container.getDevices();
        for (int i = devices.size() - 1; i >= 0; i--) {
            if (container.getPowerUsage() <= budget) break;
            devices.get(i).deactivate();
        }
    }

    @Override
    public String getStatus() {
        return "ECO " + budget + "W budget\n" + super.getStatus();
    }

    public List<SmartDevice> getDevices() { return container.getDevices(); }
    public void addDevice(SmartDevice device) { container.addDevice(device); }
    public void removeDevice(SmartDevice device) { container.removeDevice(device); }
    public String getName() { return container.getName(); }
}

class GuestMode extends DeviceDecorator implements DeviceContainer {
    private final DeviceContainer container;
    private final Set<Class<?>> allowed;

    public GuestMode(DeviceContainer container, Set<Class<?>> allowed) {
        super(container);
        this.container = container;
        this.allowed = allowed;
    }

    private boolean isAllowed(SmartDevice device) {
        SmartDevice base = device.getBaseDevice();
        for (Class<?> allowedClass : allowed) {
            if (allowedClass.isInstance(base)) return true;
        }
        return false;
    }

    @Override
    public void activate() {
        for (SmartDevice device : container.getDevices()) {
            if (isAllowed(device)) device.activate();
        }
    }

    @Override
    public void deactivate() {
        for (SmartDevice device : container.getDevices()) {
            if (isAllowed(device)) device.deactivate();
        }
    }

    @Override
    public double getPowerUsage() {
        double total = 0;
        for (SmartDevice device : container.getDevices()) {
            if (isAllowed(device)) total += device.getPowerUsage();
        }
        return total;
    }

    @Override
    public String getStatus() {
        StringBuilder sb = new StringBuilder("Guest mode\n" + container.getName());
        for (SmartDevice device : container.getDevices()) {
            sb.append("\n").append(device.getStatus());
            if (!isAllowed(device)) sb.append("guest-restricted");
        }
        return sb.toString();
    }

    public List<SmartDevice> getDevices() { return container.getDevices(); }
    public void addDevice(SmartDevice device) { container.addDevice(device); }
    public void removeDevice(SmartDevice device) { container.removeDevice(device); }
    public String getName() { return container.getName(); }
}