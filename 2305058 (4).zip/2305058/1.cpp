#include<iostream>
#include<vector>
#include<queue>

using namespace std;

class Graph
{
private:
    int V;
    int E;
    vector<vector<pair<int,int>>> adj;
public:
    Graph(int v,int e)
    {
        V=v;E=e;
        int first,second,weight;
        adj.resize(V+1);
        for (int i=0;i<E;i++)
        {
            cin>>first>>second>>weight;
            adj[first].push_back({second,weight});
            adj[second].push_back({first,weight});
        }
    }
    void printGraph()
    {
        for (int i=1;i<V+1;i++)
        {
            cout<<i<<"=";
            for (auto j:adj[i])
            {
                cout<<j.first<<" "<<j.second<<" ";
            }
            cout<<endl;
        }
    }
    vector<vector<int>> floyd()
    {
        vector<vector<int>> dist(V+1,vector<int>(V+1, INT_MAX));
        for (int i=1;i<=V;i++)
        {
            dist[i][i]=0;
            for (auto edge:adj[i])
            {
                int v=edge.first;
                int w=edge.second;
                dist[i][v]=min(dist[i][v],w);
            }
        }
        for (int k=1;k<=V;k++)
            for (int i=1;i<=V;i++)
                if (dist[i][k]!=INT_MAX)
                    for (int j=1;j<=V;j++)
                        if (dist[k][j]!=INT_MAX)
                            dist[i][j]=min(dist[i][j],dist[i][k]+dist[k][j]);
        return dist;
    }
};
int main()
{
    int v,e,q;
    cin>>v>>e>>q;
    Graph g(v,e);
    //g.printGraph();
    vector<vector<int>> answer=g.floyd();
    for (int i = 0; i < q; i++)
    {
        int u, v;
        cin>>u>>v;
        if (answer[u][v]==INT_MAX)
            cout<<-1<<endl;
        else
            cout<<answer[u][v]<<endl;
    }
    return 0;
}
